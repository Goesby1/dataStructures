package bpt;

import bpt.UnimplementedMethodException;

import java.util.Iterator;

import org.junit.internal.builders.NullBuilder;

/**
 * <p>{@code BinaryPatriciaTrie} is a Patricia Trie over the binary alphabet &#123;	 0, 1 &#125;. By restricting themselves
 * to this small but terrifically useful alphabet, Binary Patricia Tries combine all the positive
 * aspects of Patricia Tries while shedding the storage cost typically associated with tries that
 * deal with huge alphabets.</p>
 *
 * @author Yosefe Eshete
 */
public class BinaryPatriciaTrie {

    /* We are giving you this class as an example of what your inner node might look like.
     * If you would prefer to use a size-2 array or hold other things in your nodes, please feel free
     * to do so. We can *guarantee* that a *correct* implementation exists with *exactly* this data
     * stored in the nodes.
     */
    private static class TrieNode {
        private TrieNode left, right;
        private String str;
        private boolean isKey;

        // Default constructor for your inner nodes.
        TrieNode() {
            this("", false);
        }

        // Non-default constructor.
        TrieNode(String str, boolean isKey) {
            left = right = null;
            this.str = str;
            this.isKey = isKey;
        }
    }

    private TrieNode root;
    private int size;

    /**
     * Simple constructor that will initialize the internals of {@code this}.
     */
    public BinaryPatriciaTrie() {
        //throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
        root = new TrieNode();
        size = 0; 
    }

    /**
     * Searches the trie for a given key.
     *
     * @param key The input {@link String} key.
     * @return {@code true} if and only if key is in the trie, {@code false} otherwise.
     */
    public boolean search(String key) {
    //    throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
        int len = key.length();
        char firstChar; 
        int plc;
        TrieNode curr = root; 
        String temp = ""; 
    
        while (true) {
            
            if (key.isEmpty() && curr.isKey && temp.length() == curr.str.length()) {
                return true;
            } else if (key.isEmpty()) {
                break;
            }

            firstChar = key.charAt(0);
            plc = 0; 

            if (firstChar == '0') {
                if (curr.left != null) { 
                    for (int i = 0; i < Math.min(curr.left.str.length(),key.length()); i++) {
                        if ( curr.left.str.charAt(i) == key.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                }
                temp = key.substring(0, plc);
                key = key.substring(plc);

                if (plc == 0) {
                    break;
                } else {
                    curr = curr.left;
                }
            } else {
                if (curr.right != null) { 
                    for (int i = 0; i < Math.min(curr.right.str.length(),key.length()); i++) {
                        if (curr.right != null && curr.right.str.charAt(i) == key.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                }
                temp = key.substring(0, plc);
                key = key.substring(plc);

                if (plc == 0) {
                    break;
                }else {
                    curr = curr.right;
                }
            }
        }
        return false;
    }   

    /**
     * Inserts key into the trie.
     *
     * @param key The input {@link String}  key.
     * @return {@code true} if and only if the key was not already in the trie, {@code false} otherwise.
     */
    public boolean insert(String key) {
    //   throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
        char firstChar; 
        int plc = 0;
        TrieNode curr = root;
        TrieNode tmp;
        String temp = ""; 
        String temp2 = "";
        String key2 = "";

        while (true) {
            
            /** If the key is empty and we stop at a KEY node that has the same previous length as our current,
            *   then the item is already in the trie. (Return false)
            */ 
            if (key.isEmpty() && curr.isKey  && temp.length() == curr.str.length()) {
                return false;
            
            }
            /** If the key is empty and we stop on a none KEY node and it has the same previous length as our current,
            *   then set the node to key(make isKey = true), then break
            */ 
             else if (key.isEmpty() && !curr.isKey &&  temp.length() == curr.str.length()) {
                curr.isKey = true;
                break;
            } 
            /** If it doesn't meet the above two conditions then create a new Key node and add it to the left or right of the prevCurr node. 
             *  Basically just add a new node.
             */
            /*
            else if (key.isEmpty() && !temp.isEmpty()) {
        
                // Get the string of the new node and store it in tmp. 
                key = temp.substring(plc);
                tmp = new TrieNode(temp, true);
                // If the first value of temp is 0, then add to the left.
                if (temp.charAt(0) == '0'){
                    prevCurr.left = tmp;
                    // If the current node is not null 
                    if (curr != null && curr.str.charAt(0) == '0') {
                        curr.str = key; 
                        tmp.left = curr;
                    } else if (curr != null && curr.str.charAt(0) == '1') {
                        curr.str = key; 
                        tmp.right = curr;
                    }

                } 
                // If the first value of the temp is 0, then add to the right 
                else {
                    prevCurr.right = tmp;
                    if (curr.str.charAt(0) == '0') {
                        curr.str = key; 
                        tmp.left = curr;
                    } else {
                        curr.str = key; 
                        tmp.right = curr;
                    }
                }

            }
*/
            firstChar = key.charAt(0);
            plc = 0; 

            // Find which node to examine next. Go to the left 
            if (firstChar == '0') {
                if (curr.left != null) { 
                    for (int i = 0; i < Math.min(curr.left.str.length(),key.length()); i++) {
                        if (curr.left.str.charAt(i) == key.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                }
                // If the node is a null 
                /*
                if (plc == 0) {
                    for (int i = 0; i < Math.min(curr.str.length(),temp.length()); i++) {
                        if (curr.str.charAt(i) == temp.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                    // This means the current key has some matching element with the key
                    key = key.substring(plc);
                    if (plc > 0) {
                        temp = curr.str.substring(plc);
                        
                        key2 = curr.str.substring(0, plc);
                        curr.str = temp; 
                        //curr.isKey = false; 
                        // Redefine 
                        tmp = curr.left;
                        if (temp.charAt(0) == '0') {
                            curr.left = new TrieNode(key2,false);
                            curr.left.left = tmp;
                            if (!key.isEmpty()) {
                                curr.left.right = new TrieNode(key,true);  
                            } else {
                                curr.left.isKey = true;
                            }
                        } else {
                            curr.left = new TrieNode(key2,false);
                            curr.left.right = tmp;
                            if (!key.isEmpty()) {
                                curr.left.left = new TrieNode(key,true);  
                            } else {
                                curr.left.isKey = true;
                            }
                        }

                    } else {

                        curr.left = new TrieNode(key,true);
                        
                    }

                    break;

                }*/
                if (plc == 0) {
                    key = key.substring(plc);

                    curr.left = new TrieNode(key,true);
                    break;
                }
                else if (curr.left != null && plc != 0 && plc < curr.left.str.length()) {
                    temp = curr.left.str.substring(plc);
                    key = key.substring(plc);

                    key2 = curr.left.str.substring(0,plc);
                    curr.left.str = temp; 
                    // Redefine 
                    tmp = curr.left;
                    if (temp.charAt(0) == '0') {
                        curr.left = new TrieNode(key2,false);
                        curr.left.left = tmp;
                        if (!key.isEmpty()) {
                            curr.left.right = new TrieNode(key,true);  
                        } else {
                            curr.left.isKey = true;
                        }
                    } else {
                        curr.left = new TrieNode(key2,false);
                        curr.left.right = tmp;
                        if (!key.isEmpty()) {
                            curr.left.left = new TrieNode(key,true);  
                        } else {
                            curr.left.isKey = true;
                        }
                    }


                    break; 
                } else {

                 
                    temp = key.substring(0, plc);
                    key = key.substring(plc);
                    curr = curr.left; 
                }
            }
            
            //Go to the right 
            else {
                if (curr.right != null) { 
                    for (int i = 0; i < Math.min(curr.right.str.length(),key.length()); i++) {
                        if (curr.right.str.charAt(i) == key.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                }

                /*if (plc == 0) {
                    for (int i = 0; i < Math.min(curr.str.length(),temp.length()); i++) {
                        if (curr.str.charAt(i) == temp.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                    key = key.substring(plc);
                    if (plc > 0) {
                        temp = curr.str.substring(plc);
                        key2 = curr.str.substring(0, plc);
                        curr.str = temp; 
                        //curr.isKey = false; 
                        // Redefine 
                        tmp = curr.right;
                        if (temp.charAt(0) == '0') {
                            curr.left = new TrieNode(key2,false);
                            curr.left.left = tmp;
                            if (!key.isEmpty()) {
                                curr.left.right = new TrieNode(key,true);  
                            } else {
                                curr.left.isKey = true;
                            }
                        } else {
                            curr.left = new TrieNode(key2,false);
                            curr.left.right = tmp;
                            if (!key.isEmpty()) {
                                curr.left.left = new TrieNode(key,true);  
                            } else {
                                curr.left.isKey = true;
                            }
                        }
                    } else {

                        
                        curr.right = new TrieNode(key, true);
                        
                    }

                    break;
                }*/
                if (plc == 0) {
                    key = key.substring(plc);
                    curr.right = new TrieNode(key, true);
                    break;
                }
                else if (curr.right != null && plc != 0 && plc < curr.right.str.length()) {
                    temp = curr.right.str.substring(plc);
                    key = key.substring(plc);
                    key2 = curr.right.str.substring(0, plc);
                    curr.right.str = temp; 
                    // Redefine 
                    tmp = curr.right;
                    if (temp.charAt(0) == '0') {

                        curr.right = new TrieNode(key2,false);
                        curr.right.left = tmp;
                        if(!key.isEmpty()){
                            curr.right.right = new TrieNode(key,true);  
                        } else {
                            curr.right.isKey = true; 
                        }
                    } else {
                        curr.right = new TrieNode(key2,false);
                        curr.right.right = tmp;
                        if (!key.isEmpty()) {
                            curr.right.left = new TrieNode(key,true);  
                        }else {
                            curr.right.isKey = true; 
                        }

                    }


                    break; 
                } 
                 else {
                 
                    temp = key.substring(0, plc);   
                    key = key.substring(plc);
                    curr = curr.right;
                }

            }
        }

        this.size++;
        return true;


    }


    /**
     * Deletes key from the trie.
     *
     * @param key The {@link String}  key to be deleted.
     * @return {@code true} if and only if key was contained by the trie before we attempted deletion, {@code false} otherwise.
     */
    public boolean delete(String key) {
    //    throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
        char firstChar; 
        int plc = 0;
        TrieNode curr = root;
        TrieNode prevCurr = curr;
        String temp = ""; 

        while (true) {
            
            /** If the key is empty and we stop at a KEY node that has the same previous length as our current,
            *   then the item is already in the trie. (Return false)
            */ 
            if (key.isEmpty() && curr.isKey  && temp.length() == curr.str.length()) {
                if (curr.left == null && curr.right == null) {
                    curr = null;

                    if (prevCurr.isKey == false) {
                        if (prevCurr.left == null) {
                            prevCurr.str = prevCurr.str.concat(prevCurr.right.str);
                            prevCurr.isKey = true;
                            prevCurr.left = prevCurr.right.left;
                            prevCurr.right = prevCurr.right.right; 
                        } else {
                            prevCurr.str = prevCurr.str.concat(prevCurr.left.str);
                            prevCurr.isKey = true;
                            prevCurr.right = prevCurr.left.right; 
                            prevCurr.left = prevCurr.left.left;
                        }
                    } 


                } else if (curr.left == null && curr.right != null) {
                    curr.str = curr.str.concat(curr.right.str);
                    curr.left = curr.right.left;
                    curr.right = curr.right.right;
                } else if (curr.right == null && curr.left != null) {
                    curr.str = curr.str.concat(curr.left.str);
                    curr.left = curr.left.right;
                    curr.right = curr.left.left;
                } else if (curr.right != null && curr.left != null){
                    curr.isKey = false;
                }
                this.size--;
                return true;
            }
            /** If the key is empty and we stop on a none KEY node and it has the same previous length as our current,
            *   then set the node to key(make isKey = true), then break
            */ 
            else if (key.isEmpty() && !curr.isKey &&  temp.length() == curr.str.length()) {
                break;
            } 
            

            firstChar = key.charAt(0);
            plc = 0; 

            // Find which node to examine next. Go to the left 
            if (firstChar == '0') {
                if (curr.left != null) { 
                    for (int i = 0; i < Math.min(curr.left.str.length(),key.length()); i++) {
                        if (curr.left.str.charAt(i) == key.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                }
                
                if (plc == 0) {
                    break;
                }
                else if (curr.left != null && plc != 0 && plc < curr.left.str.length()) {
                   
                    break; 
                } else {

                    temp = key.substring(0, plc);
                    key = key.substring(plc);
                    prevCurr = curr;
                    curr = curr.left; 
                }
            }
            
            //Go to the right 
            else {
                if (curr.right != null) { 
                    for (int i = 0; i < Math.min(curr.right.str.length(),key.length()); i++) {
                        if (curr.right.str.charAt(i) == key.charAt(i) ) {
                            plc++;
                        } else {
                            break;
                        }
                    }
                }
                

                if (plc == 0) {
                    break;
                }
                else if (curr.right != null && plc != 0 && plc < curr.right.str.length()) {
                  

                    break; 
                } 
                else {
                    
                    temp = key.substring(0, plc);
                    key = key.substring(plc);
                    prevCurr = curr;
                    curr = curr.right;
                }

            }
        }

        return false;




    }

    /**
     * Queries the trie for emptiness.
     *
     * @return {@code true} if and only if {@link #getSize()} == 0, {@code false} otherwise.
     */
    public boolean isEmpty() {
     //   throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
        return (this.getSize() == 0)? true: false;
    }

    /**
     * Returns the number of keys in the tree.
     *
     * @return The number of keys in the tree.
     */
    public int getSize() {
    //    throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
        return this.size; 
    }

    /**
     * <p>Performs an <i>inorder (symmetric) traversal</i> of the Binary Patricia Trie. Remember from lecture that inorder
     * traversal in tries is NOT sorted traversal, unless all the stored keys have the same length. This
     * is of course not required by your implementation, so you should make sure that in your tests you
     * are not expecting this method to return keys in lexicographic order. We put this method in the
     * interface because it helps us test your submission thoroughly and it helps you debug your code! </p>
     *
     * <p>We <b>neither require nor test </b> whether the {@link Iterator} returned by this method is fail-safe or fail-fast.
     * This means that you  do <b>not</b> need to test for thrown {@link java.util.ConcurrentModificationException}s and we do
     * <b>not</b> test your code for the possible occurrence of concurrent modifications.</p>
     *
     * <p>We also assume that the {@link Iterator} is <em>immutable</em>, i,e we do <b>not</b> test for the behavior
     * of {@link Iterator#remove()}. You can handle it any way you want for your own application, yet <b>we</b> will
     * <b>not</b> test for it.</p>
     *
     * @return An {@link Iterator} over the {@link String} keys stored in the trie, exposing the elements in <i>symmetric
     * order</i>.
     */
    public Iterator<String> inorderTraversal() {
       // throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!

       Iterator<String> bob = null; 
       
       return bob;

    }

    /**
     * Finds the longest {@link String} stored in the Binary Patricia Trie.
     * @return <p>The longest {@link String} stored in this. If the trie is empty, the empty string &quot;&quot; should be
     * returned. Careful: the empty string &quot;&quot;is <b>not</b> the same string as &quot; &quot;; the latter is a string
     * consisting of a single <b>space character</b>! It is also <b>not the same as the</b> null <b>reference</b>!</p>
     *
     * <p>Ties should be broken in terms of <b>value</b> of the bit string. For example, if our trie contained
     * only the binary strings 01 and 11, <b>11</b> would be the longest string. If our trie contained
     * only 001 and 010, <b>010</b> would be the longest string.</p>
     */
    public String getLongest() {
    //    throw new UnimplementedMethodException(); // ERASE THIS LINE AFTER YOU IMPLEMENT THE METHOD!
    return "";
    }

    /**
     * Makes sure that your trie doesn't have splitter nodes with a single child. In a Patricia trie, those nodes should
     * be pruned.
     * @return {@code true} iff all nodes in the trie either denote stored strings or split into two subtrees, {@code false} otherwise.
     */
    public boolean isJunkFree(){
        return isEmpty() || (isJunkFree(root.left) && isJunkFree(root.right));
    }

    private boolean isJunkFree(TrieNode n){
        if(n == null){   // Null subtrees trivially junk-free
            return true;
        }
        if(!n.isKey){   // Non-key nodes need to be strict splitter nodes
            return ( (n.left != null) && (n.right != null) && isJunkFree(n.left) && isJunkFree(n.right) );
        } else {
            return ( isJunkFree(n.left) && isJunkFree(n.right) ); // But key-containing nodes need not.
        }
    }
}
